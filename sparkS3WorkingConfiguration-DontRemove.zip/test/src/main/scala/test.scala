import java.util.regex.Pattern

import org.apache.spark.SparkConf
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.DateTime
import org.apache.hadoop._
import org.apache.hadoop.fs.s3a._
import org.apache.hadoop.fs._
import org.apache.hadoop.fs
import org.apache.hadoop.conf.Configuration._

object test {
  def setupLogging() = {
    import org.apache.log4j.{Level, Logger}
    val rootLogger = Logger.getRootLogger()
    rootLogger.setLevel(Level.ERROR)
    Logger.getLogger("org").setLevel(Level.ERROR)
    Logger.getLogger("akka").setLevel(Level.ERROR)
  }
  def createSparkSession(): SparkSession = {
    val mem = "16g"
    val spark_warehouse = "./spark-wh" // "spark-warehouse"
    val conf = new SparkConf()

    val ss = SparkSession.builder.appName("BlinkFirst").master("local[*]")
      .config("spark.sql.warehouse.dir", spark_warehouse)
      .config("hive.metastore.warehouse.dir", spark_warehouse)
      .config("spark.executors", "4")
      .config("spark.executor.memory", "12g")
      .config("spark.driver.memory", "12g")
      .config("spark.executor.cores", "6")
      .config("spark.cores.max", "6")
      .config("spark.memory.offHeap.enabled", true)
      .config("spark.memory.offHeap.size", "16g")
      .config("spark.sql.broadcastTimeout", "36000")
      .config("spark.sql.shuffle.partitions", 2000)
      .config("spark.sql.files.maxPartitionBytes", 1024 * 1024 * 128)
      .config("spark.sql.tungsten.enabled", true)
      .config("maximizeResourceAllocation", true)
      .config("spark.dynamicAllocation.enable", true)
      .config("spark.sql.parquet.cacheMetadata", true)
      .config("spark.sql.parquet.compression.codec", "gzip")
      .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
      .config("spark.databricks.optimizer.dynamicPartitionPruning","true")
      .config("spark.databricks.delta.properties.defaults.autoOptimize.optimizeWrite", true)
      .config("spark.databricks.delta.properties.defaults.autoOptimize.autoCompact", true)
      .config("fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
      .config("fs.s3n.awsAccessKeyId", "AKIASLS6WKNA5LMUOL7S")
      .config("fs.s3n.awsSecretAccessKey", "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")
      .getOrCreate()

    ss.sparkContext
      .hadoopConfiguration
      .set("fs.s3n.impl","org.apache.hadoop.fs.s3native.NativeS3FileSystem")
    ss.sparkContext
      .hadoopConfiguration
      .set("fs.s3n.awsAccessKeyId", "AKIASLS6WKNA5LMUOL7S")
    ss.sparkContext
      .hadoopConfiguration
      .set("fs.s3n.awsSecretAccessKey", "MnmNkilMFO9z2iagg0UbEhO3kljDb8F8YZ9amwJ5")

    ss.sparkContext
      .hadoopConfiguration
      .set("awsAccessKeyId", "AKIASLS6WKNA5LMUOL7S")
    ss.sparkContext
      .hadoopConfiguration
      .set("awsSecretAccessKey", "MnmNkilMFO9z2iagg0UbEhO3kljDb8F8YZ9amwJ5")
    val AWS_KEY = "AKIASLS6WKNA5LMUOL7S"
    val AWS_SECRET_KEY = "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"
    ss.sparkContext.hadoopConfiguration.set("fs.s3a.access.key", AWS_KEY);
    ss.sparkContext.hadoopConfiguration.set("fs.s3a.secret.key", AWS_SECRET_KEY);


    // "spark.sql.parquet.filterPushdown"
    //  spark.default.parallelism
    //  spark.executor.extraJavaOptions
    ss

  }

  def main(args: Array[String]) {
    setupLogging()

    val ss = createSparkSession()
    println ("Welcome to rSquare...")

    val df = ss.read.format("csv").option("header", true).option("delimiter", "|").load("s3a://mrc-dl-test/test/categories.csv")
    df.show()
    //    val dl = new diFlow()
    //    val md = new mrcMetaData()
    //    md.getSourceDefinition()
  }
}