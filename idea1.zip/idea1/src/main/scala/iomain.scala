package mihica.io

import mihica.io.utilities._
import mihica.io.ioFlow

object iomain {
  def main(args: Array[String]) {
    setupLogging()
    println ("Welcome to rSquare...")
    val dfl = new ioFlow()
    //    val dl = new diFlow()
    //    val md = new mrcMetaData()
    //    md.getSourceDefinition()
  }
}
