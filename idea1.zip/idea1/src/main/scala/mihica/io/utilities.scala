package mihica.io

import java.util.regex.Pattern

import org.apache.spark.SparkConf
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.DateTime

object utilities {

  /** Makes sure only ERROR messages get logged to avoid log spam. */
  def setupLogging() = {
    import org.apache.log4j.{Level, Logger}
    val rootLogger = Logger.getRootLogger()
    rootLogger.setLevel(Level.ERROR)
    Logger.getLogger("org").setLevel(Level.ERROR)
    Logger.getLogger("akka").setLevel(Level.ERROR)
  }
  /** Configures Twitter service credentials using twiter.txt in the main workspace directory */
  def setupTwitter() = {
    import scala.io.Source

    for (line <- Source.fromFile("../twitter.txt").getLines) {
      val fields = line.split(" ")
      if (fields.length == 2) {
        System.setProperty("twitter4j.oauth." + fields(0), fields(1))
      }
    }
  }
  /** Retrieves a regex Pattern for parsing Apache access logs. */
  def apacheLogPattern(): Pattern = {
    val ddd = "\\d{1,3}"
    val ip = s"($ddd\\.$ddd\\.$ddd\\.$ddd)?"
    val client = "(\\S+)"
    val user = "(\\S+)"
    val dateTime = "(\\[.+?\\])"
    val request = "\"(.*?)\""
    val status = "(\\d{3})"
    val bytes = "(\\S+)"
    val referer = "\"(.*?)\""
    val agent = "\"(.*?)\""
    val regex = s"$ip $client $user $dateTime $request $status $bytes $referer $agent"
    Pattern.compile(regex)
  }

  /** Create and return spark session  */
  def createSparkSession(): SparkSession = {
    val mem = "16g"
    val spark_warehouse = "./spark-wh" // "spark-warehouse"
    val conf = new SparkConf()

    val ss = SparkSession.builder.appName("BlinkFirst").master("local[*]")
      .config("spark.sql.warehouse.dir", spark_warehouse)
      .config("hive.metastore.warehouse.dir", spark_warehouse)
      .config("spark.executors", "4")
      .config("spark.executor.memory", "12g")
      .config("spark.driver.memory", "12g")
      .config("spark.executor.cores", "6")
      .config("spark.cores.max", "6")
      .config("spark.memory.offHeap.enabled", true)
      .config("spark.memory.offHeap.size", "16g")
      .config("spark.sql.broadcastTimeout", "36000")
      .config("spark.sql.shuffle.partitions", 2000)
      .config("spark.sql.files.maxPartitionBytes", 1024 * 1024 * 128)
      .config("spark.sql.tungsten.enabled", true)
      .config("maximizeResourceAllocation", true)
      .config("spark.dynamicAllocation.enable", true)
      .config("spark.sql.parquet.cacheMetadata", true)
      .config("spark.sql.parquet.compression.codec", "gzip")
      .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
      .config("spark.databricks.optimizer.dynamicPartitionPruning","true")
      .config("spark.databricks.delta.properties.defaults.autoOptimize.optimizeWrite", true)
      .config("spark.databricks.delta.properties.defaults.autoOptimize.autoCompact", true)
      .getOrCreate()

    // "spark.sql.parquet.filterPushdown"
    //  spark.default.parallelism
    //  spark.executor.extraJavaOptions
    ss

  }
  def getDate(d: Int = 0): String = {
    val now = DateTime.now
    now.plusDays(d).toString("YYYY-MM-dd")
  }
  def getDateTime(d: Int = 0): String = {
    val now = DateTime.now
    now.plusDays(d).toString("YYYY-MM-dd HH:mm:ss")
  }

  /** Data Processing methods **/
  /** Reader Methods: File Reader and JDBC Reader*/
  def fileReader (ss: SparkSession, location: String, fileFormat: String = "CSV", sep: String = "|", header: Boolean = true, filterClause: String = "", selectClause: Array[String] = Array(), tabName: String = "Sheet1"): DataFrame = {
    println ("Location: " + location)
    try {
      fileFormat.toUpperCase() match {
        case "CSV" => ss.read.format("csv").option("header", header).option("delimiter", sep).load(location).transform({ ds => if (filterClause.isEmpty) ds else ds.filter(filterClause)}).transform({ ds => if (selectClause.isEmpty) ds else ds.select(selectClause(0), selectClause.slice(1,10000): _*)})
        case "PARQUET" => ss.read.parquet(location).transform({ ds => if (filterClause.isEmpty) ds else ds.filter(filterClause) }).transform({ ds => if (selectClause.isEmpty) ds else ds.select(selectClause(0), selectClause.slice(1,10000): _*)})
        case "ORC" => ss.read.orc(location).transform({ ds => if (filterClause.isEmpty) ds else ds.filter(filterClause) }).transform({ ds => if (selectClause.isEmpty) ds else ds.select(selectClause(0), selectClause.slice(1,10000): _*)})
        case "JSON" => ss.read.json(location)
      }
    }
    catch {
      case e: Exception => {
        println("Error in creating dataset " + e)
        //        ss.sql("select ''")
        ss.emptyDataFrame
      }
    }
  }
  def createDBTable (df: DataFrame, location: String, format: String, recordsPerFile: Int = 10000, tableName: String, mode: String = "overwrite", partitionColumns: Seq[String] = Seq(""), buckets: Int = 5, bucketColumns: Array[String] = Array(""), loopPartions: Boolean = false): Boolean = {
    println(location)
    try {
      //      df.write.format(format).option("maxRecordsPerFile", recordsPerFile).mode(mode).partitionBy(partitionColumns).bucketBy(buckets, bucketColumns(0), bucketColumns.slice(1,100): _*).sortBy(bucketColumns(0), bucketColumns.slice(1,100): _*).option(if (format == "PARQUET") "compression" else "orc.compression" ,"gzip").option("path", location).saveAsTable(tableName)
      df.coalesce(10).write.format(format).option("maxRecordsPerFile", recordsPerFile).mode(mode).partitionBy(partitionColumns: _*).option("compression", "gzip").save(location)
      //      df.coalesce(10).write.format(format).option("maxRecordsPerFile", recordsPerFile).mode(mode).partitionBy(partitionColumns: _*).sortBy(bucketColumns(0), bucketColumns.slice(1,100): _*).save(location)
      // .bucketBy(buckets, bucketColumns(0), bucketColumns.slice(1,100): _*).sortBy(bucketColumns(0), bucketColumns.slice(1,100): _*).option("compression", "gzip").option("path", location).saveAsTable(tableName)
      if (loopPartions) {
        if (partitionColumns.isEmpty) {
          try {
            df.write.format(format).option("maxRecordsPerFile", recordsPerFile).option("compression", "gzip").mode(mode).bucketBy(buckets, bucketColumns(0), bucketColumns.slice(1,100): _*).sortBy(bucketColumns(0), bucketColumns.slice(1,100): _*).option("path", location).parquet(tableName)
            //            df.write.format(format).option("maxRecordsPerFile", recordsPerFile).option("compression", "gzip").mode(mode).bucketBy(buckets, bucketColumns(0), bucketColumns.slice(1,100): _*).sortBy(bucketColumns(0), bucketColumns.slice(1,100): _*).option("path", location).saveAsTable(tableName)
            true
          }
          catch {
            case e: Exception => {
              println ("Error in creating dataset " + e)
              false
            }
          }
        }
      }
      else {

      }
      true
    }
    catch {
      case e: Exception => {
        println ("Error in creating dataset " + e)
        false
      }
    }
  }

  /** Build Repo **/
  def generateRepo(ss: SparkSession): Unit = {
    val subscriptionSQL = "SELECT  s.subscriberid, s.Name, s.contact, se.subscriptionid, se.DatasetId, se.Frequency, se.ScheduleTime, se.LastProvisionTimeStamp, se.ProvisionFormat, se.Compressed FROM    subscribers s, subscription se WHERE   s.SubscriberId = se.SubscriberId AND s.Active = 'Y' and s.SubscriberId = 1"
    val dsSQL = "SELECT    d.DatasetId, d.Name, d.Location, d.Format, d.Delimiter, d.Header FROM Datasets d WHERE d.Active = 'Y' and d.DatasetId = 1"
    val repoFile = "/Users/ravi.mannepalli/dScripts/Projcts/subscriberModel/" // SubscriptionModel.xlsx"
    val sheets = Seq("Subscribers", "Datasets", "DatasetAttributes", "Subscription", "SubscriptionAttributes")
    for (i <- sheets) {
      val tDF = ss.sqlContext.read
        .format("com.crealytics.spark.excel")
        .option("useHeader", "true") // Required
        .option("treatEmptyValuesAsNulls","true") // Optional, default: true
        .option("inferSchema", "true") //Optional, default: false
        .option("addColorColumns", "false") //Required
        .option("timestampFormat", "MM-dd-yyyy HH:mm:ss") // Optional, default: yyyy-mm-dd hh:mm:ss[.fffffffff] .schema(schema)
        .option("sheetName", "DatasetAttribute")
        .load(repoFile + i + ".xlsx")
      tDF.createOrReplaceTempView(i)
      println (i)
      //      tDF.show()
      //      ss.sql ("SELECT * FROM " + i ).show()
    }

    //    val subsriptions = ss.sql (subscriptionSQL)
    //    for (i <- subsriptions.collect()) {
    //      val ds = ss.sql (dsSQL)
    //      ds.show()
    //      for (dsItem <- ds.collect()) {
    //        val newSQL = ss.sql("SELECT    CONCAT(da.Name, ' as ',  sa.Alias_or_OutputName) colName FROM DatasetAttributes da, SubscriptionAttributes sa WHERE da.AttributeID = sa.DatasetAttributeID AND da.DatasetId = " + i(4))
    //
    //        val t = newSQL.collect().map(_.mkString).mkString(", ")
    //        //        println (t)
    //        val sqlStr = "SELECT " + t + " FROM " + dsItem(3) + ".`" + dsItem(2) + "` WHERE 1=1"
    //        print (sqlStr)
    //        //
    //      }
    //      //      val sqlString = "SELECT d.name as DatasetName, da.name as attributeName, sa.Alias_or_OutputName as aliasName FROM Datasets d, DatasetAttributes da, SubscriptionAttributes sa where d.DatasetId = da.DatasetId and d.DatasetId = " + i(1)
    //    }
  }

  /** Process log handlers */
  def logProcess(ds: String, stTime: String, processStatus: String = "Initiated", msg: String = ""): Boolean = {
    println (ds + " " + stTime + " " + processStatus + " " + msg)
    true
  }

  def logProcessStatus(ds: String, processStatus: String = "Initiated", msg: String = ""): Boolean = {
    println (ds + " " + DateTime.now.toString() + " " + processStatus + " " + msg)
    true
  }
}
