package mihica.io

import org.apache.spark.sql.{DataFrame, SparkSession}
import utilities._

import scala.collection.mutable.ArrayBuffer
import org.apache.spark.sql.functions._
import org.json4s.jackson.Json
import java.time.format.DateTimeFormatter
import io.delta.tables._

//* Data Structures
case class dsStorageFormat (Name: String = "CSV", ColumnSeparator: String = "|", Header: Boolean = true, LineSeparator: String = "\n", CompressionCodec: String = null, RowsPereFile: Int = 200000)
case class dsAttribute (Name: String, DataType: String, Expression: String, Length: Int, Decimal: Int, Default: String = null)
case class dsStorageShards (PartitionColumns: Seq[String] = Seq(""), Buckets: Int = 5, BucketColumns: Array[String] = Array(""))
case class dsColumnExpression (Name: String, Expression: String, Default: String = null)

case class dsStructure (Name: String, Location: String, Format: dsStorageFormat, Attributes: Array[dsAttribute] = null, FilterClause: String = null, SelectClause: Array[String] = Array(), QueryOverWrite: String = null, TargetType: String = "SCD0")
case class dsSrcTrg (src: dsStructure, trg: dsStructure, dsShards: Seq[String] = null)

//*** Process Structures
case class diDF (Name: String, df: DataFrame)
case class dsFilter (Name: String, ds1: String, FilterCondition: String)
case class diWorklet (Name: String, Type: String, Seq: Double, Content: Any, Source: String = null)
case class diWorkFlow (Name: String, Worklets: Array[diWorklet])
case class dsJoin (Name: String, Sources: Array[String] = Array(""), JoinCondition: String, JoinFilter: String = null, SelectClause: String = null)
case class dsFork (Name: String, Source: String, ForkCondition: String)


class ioFlow {

  val ss = utilities.createSparkSession()
  var wfDFS = ArrayBuffer[diDF]()
  var wlDef = Array[diWorklet]()

  //*** Final Processing Methods
  def getDF(name: String): DataFrame = wfDFS.find(_.Name == (name)).getOrElse(diDF(null, null)).df;
  def showDF(name: String, r: Int = 50): Boolean = {
    //*** Fetches and shows rows from a dataframe class diDF for a given object name
    getDF(name).show(r)
    true
  }
  def addColumns (df: DataFrame, addlColumns: Array[dsColumnExpression] = Array(dsColumnExpression("", ""))): DataFrame = {
    var d = df
    addlColumns.foreach( x=> {
      try {
        d = d.withColumn(x.Name, expr(x.Expression.toString))
      }
      catch {
        case e: Exception => d = d.withColumn(x.Name, expr(x.Default.toString))
      }
    })
    // d.show()
    d
  }

  // Based on data structure details, generates new Data Frame object by reading data from the specified location
  def generateSource(WorkletName: String, src: dsStructure): diDF = diDF(WorkletName, dsObjReader(src));
  // Adds new columns to a Data Frame based on definitions provided in addlColumns
  def generateAdditionalColumns(name: String, df: DataFrame, addlColumns: Array[dsColumnExpression]): diDF = {
    //    for (i <- addlColumns) println (i)
    diDF(name, addColumns(df, addlColumns))
  }
  // Apply filters
  def generateFilterDF(name: String, filterStructure: dsFilter): diDF = diDF(name, getDF(filterStructure.ds1).filter(filterStructure.FilterCondition))
  // Join one or more than one data frame using Join Conditions and also allow selection and filter features
  def generateJoinDFs(name: String, joinStructure: dsJoin): diDF = {
    for (src <- joinStructure.Sources) {
      getDF(src).createOrReplaceTempView(src)
    }
    diDF(name, ss.sql(joinStructure.SelectClause + " WHERE " + joinStructure.JoinCondition + " " + joinStructure.JoinFilter))
  }
  // Create Fork/Router for condition
  def generateForkDFS(name: String, fStructure: dsFork): Boolean = {
    wfDFS += diDF(name + "_true", getDF(fStructure.Source).filter(fStructure.ForkCondition))
    wfDFS += diDF(name + "_false", getDF(fStructure.Source).filter("not (" + fStructure.ForkCondition + ")"))
    true
  }

  /** Reader Methods: File Reader and JDBC Reader */
  def dsObjReader(dsObj: dsStructure): DataFrame = {
    try {
      dsObj.Format.Name.toUpperCase() match {
        case "CSV" => ss.read.format("csv").option("header", dsObj.Format.Header).option("delimiter", dsObj.Format.ColumnSeparator).load(dsObj.Location).transform({ ds => if (dsObj.FilterClause.isEmpty) ds else ds.filter(dsObj.FilterClause)}).transform({ ds => if (dsObj.SelectClause.isEmpty) ds else ds.select(dsObj.SelectClause(0), dsObj.SelectClause.slice(1,10000): _*)})
//        case "PARQUET" => ss.read.parquet("parquet") // .transform({ ds => if (filterClause.isEmpty) ds else ds.filter(filterClause) }).transform({ ds => if (selectClause.isEmpty) ds else ds.select(selectClause(0), selectClause.slice(1,10000): _*)})
//        case "DELTA" => ss.read.format("delta").load(dsObj.dsLocation)
//        // .transform({ ds => if (filterClause.isEmpty) ds else ds.filter(filterClause) }).transform({ ds => if (selectClause.isEmpty) ds else ds.select(selectClause(0), selectClause.slice(1,10000): _*)})
//        case "ORC" => ss.read.orc("orc") //.transform({ ds => if (filterClause.isEmpty) ds else ds.filter(filterClause) }).transform({ ds => if (selectClause.isEmpty) ds else ds.select(selectClause(0), selectClause.slice(1, 10000): _*) })
//        case "JSON" => ss.read.option("multiline", "true").json(dsObj.dsLocation) //.transform({ ds => if (filterClause.isEmpty) ds else ds.filter(filterClause) }).transform({ ds => if (selectClause.isEmpty) ds else ds.select(selectClause(0), selectClause.slice(1,10000): _*)})
      }
    }
    catch {
      case e: Exception => {
        //logProcessStatus(dsObj.dsLocation, " Failed", "Dataset doesn't exist...")
        ss.emptyDataFrame
      }
    }
  }

  def runScript(): Unit = {
    val srcLocation = "/Users/ravi.mannepalli/myData/dl/Layers/2-RAW/data.csv"
//    val srcDF = dsObjReader(dsStructure("SourceCSV", srcLocation, dsStorageFormat("CSV", ColumnSeparator = ",")))

    println("Starting Workflow...")
    processWorkFlow()
    showDF("TESTF")
    println("Workflow Process Completed...")
//    srcDF.show()
  }

  def processWorkFlow(): Boolean = {
    val srcLocation = "/Users/ravi.mannepalli/myData/dl/Layers/2-RAW/data.csv"
    //    val partitionColuns = Array(dsColumnExpression("FD_YR", "year(ORDER_DATE)"), dsColumnExpression("FD_MNTH", "month(ORDER_DATE)"), dsColumnExpression("ST_NUM", "SUBSTRING(ORDER_STATUS, 1, 1)"), dsColumnExpression("FULL_DATE", "ORDER_DATE"), dsColumnExpression("STORE_NUMBER", "ORDER_STATUS"))
    val partitionColuns = Array(dsColumnExpression("CUST_NUM", "SUBSTRING(CUSTOMER_NUM,1,1)"))

    val w: Array[diWorklet] = Array(
      diWorklet("TEST", "SOURCE", 0.1, dsStructure("SourceCSV", srcLocation, dsStorageFormat("CSV", ColumnSeparator = ","), FilterClause = "Active == true")),
      diWorklet("TESTF", "FILTER", 0.2, dsFilter("TESTF", "TEST", "Manager == 'Adolfo Rodriguez (adolfo.rodriguez)'"))
    )
    wlDef = w
    for (wl <- wlDef.sortBy(x => x.Seq)) {

      wl.Type.toUpperCase() match {
        case "SOURCE" => wfDFS += generateSource(wl.Name, wl.Content.asInstanceOf[dsStructure])
        case "JOIN" => {
          // Should work for regular join (inner, outer, left, right, leftsemi, leftanti etc)
          // also need to include union, intersect and minus operations
          //          wfDFS += generateJoinDF(ws.wlName, ws.wlContent.asInstanceOf[dsJoin], wfDFS)
          wfDFS += generateJoinDFs(wl.Name, wl.Content.asInstanceOf[dsJoin])
        }
        case "FILTER" => {
          println("Filter")
          wfDFS += generateFilterDF(wl.Name, wl.Content.asInstanceOf[dsFilter])
        } //  Though filters can be included in other widgets, a separate filter always help
        case "FORK" => generateForkDFS(wl.Name, wl.Content.asInstanceOf[dsFork])
        case "EXPR" => wfDFS += generateAdditionalColumns(wl.Name, getDF(wl.Source), partitionColuns)
        case "AGGR" => null
        case "TRG" => {
//          dsObjWriter (ss, getDF(wl.Content.asInstanceOf[dsSrcTrg].sourceObjName, wfDFS), ws.wlContent.asInstanceOf[dsSrcTrg])
        }
      }
      //      showDF(ws.wlName, wfDFS, 2)
//      var dfName = if (ws.wlType == "FORK") { ws.wlName + "_true"} else ws.wlName
      println("Executed Seq: " + wl.Seq + " Type: " + wl.Type + " Name: " + wl.Name)
      //      println("Executed Seq: " + ws.wlSeq + " Type: " + ws.wlType + " Name: " + ws.wlName + " Count: " + getDF(dfName, wfDFS).count())
      //      println(f"Executed Seq: ${ws.wlSeq%5.2f}  Type: ${ws.wlType.formatted("%-5s")}  Name: ${ws.wlName.formatted("%-50s")} Count: " + getDF(dfName, wfDFS).count() + " Time: " + utilities.getDateTime())
    }
    true
  }
  runScript()
}
